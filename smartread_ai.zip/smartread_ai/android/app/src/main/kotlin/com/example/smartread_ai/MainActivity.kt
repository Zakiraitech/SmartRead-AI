package com.example.smartread_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
