import 'package:translator/translator.dart';

class TranslationService {

  static Future<String> translate(String text) async {
    final translator = GoogleTranslator();

    var translation = await translator.translate(text, to: 'ha');

    return translation.text;
  }
}