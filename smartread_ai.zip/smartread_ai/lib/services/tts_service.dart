import 'package:flutter_tts/flutter_tts.dart';

class TTSService {

  static final FlutterTts _tts = FlutterTts();

  static speak(String text) async {
    await _tts.setLanguage("en-US");
    await _tts.setPitch(1.0);
    await _tts.speak(text);
  }
}