import 'package:flutter/material.dart';
import '../services/tts_service.dart';

(
          children: [

            Text("Detected Text", style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(detectedText),

            SizedBox(height: 20),

            Text("Hausa Translation", style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(translatedText),

            SizedBox(height: 30),

            ElevatedButton.icon(
              icon: Icon(Icons.volume_up),
              label: Text("Play Voice"),
              onPressed: () {
                TTSService.speak(translatedText);
              },
            )
          ],
        ),
      ),
    );
  }
}