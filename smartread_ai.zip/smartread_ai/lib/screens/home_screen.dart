import 'package:flutter/material.dart';
import 'camera_screen.dart';
import 'favorites_screen.dart';

class HomeScreen extends StatelessWidget {

  Widget buildCard(icon, title, context, page) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      elevation: 5,
      child: ListTile(
        leading: Icon(icon, size: 30, color: Colors.blue),
        title: Text(title),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => page),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text("SmartRead AI")),

      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            buildCard(Icons.camera_alt, "Scan Text", context, CameraScreen()),
            buildCard(Icons.star, "Favorites", context, FavoritesScreen()),
          ],
        ),
      ),
    );
  }
}