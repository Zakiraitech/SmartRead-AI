import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/ocr_service.dart';
import '../services/translation_service.dart';
import 'result_screen.dart';

class CameraScreen extends StatefulWidget {
  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {

  File? image;

  pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.camera);

    if (picked != null) {
      image = File(picked.path);

      String text = await OCRService.extractText(image!);
      String translated = await TranslationService.translate(text);

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(text, translated),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text("Scan Text")),

      body: Center(
        child: ElevatedButton(
          onPressed: pickImage,
          child: Text("Capture & Scan"),
        ),
      ),
    );
  }
}